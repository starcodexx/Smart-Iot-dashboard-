/* Smart IoT Dashboard — simulated telemetry engine
   Replace generateReading() with a real MQTT / WebSocket / REST feed
   to turn this into a live production dashboard. */

const state = {
  temp: 24,
  hum: 48,
  aqi: 32,
  motion: 6,
  history: { temp: [], hum: [], aqi: [], motion: [] }
};

const devices = [
  { name: "TEMP-SENSOR-01", room: "Server Room" },
  { name: "HUM-SENSOR-02", room: "Greenhouse" },
  { name: "AQI-SENSOR-03", room: "Lobby" },
  { name: "MOTION-04", room: "Entrance" },
  { name: "TEMP-SENSOR-05", room: "Warehouse" },
  { name: "HUM-SENSOR-06", room: "Lab B" }
];

function renderDevices() {
  const list = document.getElementById("deviceList");
  list.innerHTML = devices.map(d => `
    <li>
      <span class="dname"><span class="led"></span>${d.name}</span>
      <span class="dstat">${d.room} · online</span>
    </li>
  `).join("");
}

function clock() {
  const el = document.getElementById("clock");
  setInterval(() => {
    el.textContent = new Date().toLocaleTimeString('en-GB');
  }, 1000);
}

function clamp(v, min, max) { return Math.max(min, Math.min(max, v)); }

function step(value, drift, min, max) {
  const next = value + (Math.random() - 0.5) * drift;
  return clamp(next, min, max);
}

function setGauge(id, value, min, max) {
  const circumference = 326.7;
  const pct = (value - min) / (max - min);
  const offset = circumference * (1 - clamp(pct, 0, 1));
  document.getElementById(id).style.strokeDashoffset = offset;
}

function drawSpark(canvasId, data, color) {
  const canvas = document.getElementById(canvasId);
  const ctx = canvas.getContext("2d");
  const w = canvas.width = canvas.clientWidth;
  const h = canvas.height;
  ctx.clearRect(0, 0, w, h);
  if (data.length < 2) return;
  const min = Math.min(...data), max = Math.max(...data) || 1;
  ctx.beginPath();
  data.forEach((v, i) => {
    const x = (i / (data.length - 1)) * w;
    const y = h - ((v - min) / (max - min || 1)) * (h - 4) - 2;
    i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
  });
  ctx.strokeStyle = color;
  ctx.lineWidth = 1.5;
  ctx.stroke();
}

function pushHistory(key, value, max = 40) {
  state.history[key].push(value);
  if (state.history[key].length > max) state.history[key].shift();
}

const logMessages = [
  "Heartbeat received",
  "Threshold check passed",
  "Sync with gateway complete",
  "Sensor calibration nominal",
  "No anomalies detected"
];

function addLog(text, type = "info") {
  const feed = document.getElementById("logFeed");
  const time = new Date().toLocaleTimeString('en-GB');
  const line = document.createElement("div");
  line.className = "log-line";
  line.innerHTML = `<span class="t">${time}</span><span>${text}</span>`;
  feed.prepend(line);
  while (feed.children.length > 30) feed.removeChild(feed.lastChild);
}

// Main chart (multi-series) drawn on a plain canvas — no external deps
const mainCanvas = document.getElementById("mainChart");
const mainCtx = mainCanvas.getContext("2d");

function drawMainChart() {
  const w = mainCanvas.width = mainCanvas.clientWidth;
  const h = mainCanvas.height;
  mainCtx.clearRect(0, 0, w, h);

  // grid
  mainCtx.strokeStyle = "rgba(255,255,255,0.05)";
  mainCtx.lineWidth = 1;
  for (let i = 0; i <= 4; i++) {
    const y = (h / 4) * i;
    mainCtx.beginPath();
    mainCtx.moveTo(0, y);
    mainCtx.lineTo(w, y);
    mainCtx.stroke();
  }

  const series = [
    { data: state.history.temp, color: "#4fd8e8", range: [10, 40] },
    { data: state.history.hum, color: "#5b8cff", range: [0, 100] },
    { data: state.history.aqi, color: "#6ee7a8", range: [0, 100] }
  ];

  series.forEach(s => {
    if (s.data.length < 2) return;
    mainCtx.beginPath();
    s.data.forEach((v, i) => {
      const x = (i / (s.data.length - 1)) * w;
      const pct = (v - s.range[0]) / (s.range[1] - s.range[0]);
      const y = h - clamp(pct, 0, 1) * (h - 10) - 5;
      i === 0 ? mainCtx.moveTo(x, y) : mainCtx.lineTo(x, y);
    });
    mainCtx.strokeStyle = s.color;
    mainCtx.lineWidth = 2;
    mainCtx.stroke();
  });
}

function tick() {
  state.temp = step(state.temp, 1.2, 14, 34);
  state.hum = step(state.hum, 2.5, 20, 85);
  state.aqi = step(state.aqi, 3, 8, 95);
  state.motion = clamp(Math.round(step(state.motion, 3, 0, 20)), 0, 20);

  pushHistory("temp", state.temp);
  pushHistory("hum", state.hum);
  pushHistory("aqi", state.aqi);
  pushHistory("motion", state.motion);

  document.getElementById("tempVal").textContent = state.temp.toFixed(1);
  document.getElementById("humVal").textContent = Math.round(state.hum);
  document.getElementById("aqiVal").textContent = Math.round(state.aqi);
  document.getElementById("motionVal").textContent = state.motion;

  setGauge("tempFill", state.temp, 14, 34);
  setGauge("humFill", state.hum, 20, 85);
  setGauge("aqiFill", state.aqi, 8, 95);
  setGauge("motionFill", state.motion, 0, 20);

  drawSpark("tempSpark", state.history.temp, "#4fd8e8");
  drawSpark("humSpark", state.history.hum, "#5b8cff");
  drawSpark("aqiSpark", state.history.aqi, "#6ee7a8");
  drawSpark("motionSpark", state.history.motion, "#f5b95c");

  drawMainChart();

  if (Math.random() < 0.35) {
    addLog(logMessages[Math.floor(Math.random() * logMessages.length)]);
  }
  if (state.aqi > 80) addLog("⚠ Air quality elevated — check ventilation", "warn");
}

renderDevices();
clock();
tick();
setInterval(tick, 1800);
window.addEventListener("resize", drawMainChart);
